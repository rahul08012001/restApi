const User = require('../model/user');
const mongoose =require('mongoose');
const bcrypt =require('bcrypt');
const jwt =require('jsonwebtoken');
//const Validator=require('validator');
//const verifyToken = require('verifyToken');
const middleware =require('../middleware/authMiddleware');

const Register =async(req,res)=>{
    const user =new User({
    name:req.body?.name,
    email:req.body?.email,
    password:req.body?.password,
    mobile:req.body?.mobile,
    type:req.body?.type
    
    });
   
    console.log(user);
  const data_user=await user.save();
  //res.status(200).send({secuess:true,data:data_user})
// res.send(data_user)
return res.status(200).json({
    status: 200,
    data_user
})

}




const createToken =async (req, res) => {
    try {
    const {email, password } = req.body;
    const user = await User.findOne({ email});
   
    if (!user) {
    return res.status(401).json({ error: 'Authentication failed' });
    }
    const passwordMatch = bcrypt.compare(password, user.password);
   

    if (!passwordMatch) {
    return res.status(401).json({ error: 'Authentication failed' });
    }
    const token = jwt.sign({ userId: user._id }, 'your-secret-key', {
    expiresIn: '1h',
    });
    res.status(200).json({ 
        status : 200 , 
        message : "User login!",
        data : user,
        token : token
     });
    } catch (error) {
    res.status(500).json({ error: 'Login failed' });
    }
    }

    const getUser=async(req,res)=>
    {
        const userId =  req.userId;
        console.log("----",userId);
        const user= await User.findById(userId)
        
            res.send(user);
        console.log( user)


    }
         
    
    


module.exports ={Register,createToken,getUser};




// const userId = req.userId
//         console.log("----",userId)

//         const user = await User.findById(userId)
//         res.send(user)