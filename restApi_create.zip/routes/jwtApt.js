const express = require('express');
const router = express.Router();
const jwtApi =require('../controller/jwtApi');
const middlewareJwt =require('../middleware/authMiddleware');
const multer=require('multer')
const path =require("path")
const User = require("../model/user")
//const imagemiddleware =require('../middleware/imageMiddleware');

//const imageMiddleware=require('../middleware/imageUploade')
const {body,validationResult }=require('express-validator');
router.post("/Register",jwtApi.Register)
router.post("/Login",jwtApi.createToken)
router.get("/verifyToken",middlewareJwt,jwtApi.getUser)



const storage=multer.diskStorage({
    destination:(req,file,cd)=>{
        cd(null,'./upload/images');
console.log(storage)
    },
    filename: function (req, file, cb) {
        let ext = path.extname(file.originalname);
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        file.originalname = uniqueSuffix + ext
        cb(null,file.originalname);
        }
      })
      
    const upload = multer({ storage: storage })

router.post("/upload",upload.single("image"),async(req,res)=>{
 res.send("scess");
    const user = new User({
     email:req.body.email,
        password:req.body.password,
        image:req.file.originalname
    })
  
    await user.save();
    console.log(req.body)
    console.log(req.file)

})



//router.post("/ad1",middleware.jwtApi.createToken)s

// router.post("/createToken",
// [body('email').isEmail().trim().normalizeEmail().withMessage('Invalid email format'),
//     body('password').isEmpty().withMessage('Password is required')]
// ,
// (req,res)=> {
//     const errors = validationResult(req);
//     if(!errors.isEmpty()){s
   
    
//      jwtApi.createToken (req,res);
//     //  return res.status(400).json({errors:errors.array()})
//    }
//    }
//     )
//  //   router.get("/token",)

module.exports =router;